/* =====================================================
   HelpingHands – script.js (vanilla JavaScript)
   1 Sample data · 2 Saving · 3 Page switching · 4 Dashboard
   5 Volunteers (search, filter, add form) · 6 Events · 7 Logout · 8 Start
   ===================================================== */

/* ---------- 1. SAMPLE (DEMONSTRATION) DATA ----------
   All of this is made up. To change it, edit these two arrays.
   Each volunteer is an object: { name, email, skill, city, hours, status } */
var sampleVolunteers = [
  { name: "Aarav Mehta",  email: "aarav.mehta@example.com",  skill: "Event coordination", city: "Mumbai",    hours: 42, status: "Active" },
  { name: "Diya Sharma",  email: "diya.sharma@example.com",  skill: "Teaching",           city: "Pune",      hours: 58, status: "Active" },
  { name: "Kabir Singh",  email: "kabir.singh@example.com",  skill: "First aid",          city: "Delhi",     hours: 24, status: "Inactive" },
  { name: "Ishita Rao",   email: "ishita.rao@example.com",   skill: "Photography",        city: "Bengaluru", hours: 17, status: "Active" },
  { name: "Rohan Iyer",   email: "rohan.iyer@example.com",   skill: "Logistics",          city: "Chennai",   hours: 33, status: "Active" },
  { name: "Sneha Kulkarni", email: "sneha.k@example.com",    skill: "Fundraising",        city: "Nagpur",    hours: 9,  status: "Inactive" }
];

/* Each event: capacity = total spots, taken = spots already booked by others */
var sampleEvents = [
  { id: 1, title: "Beach Cleanup Drive",       category: "Environment", date: "Sat, 8 Nov 2026",  time: "7:00 AM",  place: "Juhu Beach",                  capacity: 30, taken: 22 },
  { id: 2, title: "Weekend Teaching Camp",     category: "Education",   date: "Sun, 16 Nov 2026", time: "10:00 AM", place: "Government School, Sector 5", capacity: 15, taken: 15 },
  { id: 3, title: "Blood Donation Camp",       category: "Health",      date: "Fri, 21 Nov 2026", time: "9:00 AM",  place: "City Community Hall",         capacity: 40, taken: 18 },
  { id: 4, title: "Food Distribution",         category: "Community",   date: "Sat, 29 Nov 2026", time: "11:00 AM", place: "Railway Station Road",        capacity: 20, taken: 12 },
  { id: 5, title: "Tree Plantation",           category: "Environment", date: "Sun, 7 Dec 2026",  time: "8:00 AM",  place: "Central Park",                capacity: 50, taken: 31 },
  { id: 6, title: "Digital Literacy Workshop", category: "Education",   date: "Sat, 13 Dec 2026", time: "2:00 PM",  place: "Public Library",              capacity: 25, taken: 10 }
];

/* These variables hold the data the page is currently using */
var volunteers = [];
var joinedEventIds = [];   // ids of events the user has joined

/* ---------- 2. SAVING WITH localStorage ----------
   localStorage is a small storage area inside YOUR browser. It keeps text
   after you refresh the page. It is not a database, not shared with other
   people or computers, and not secure. Fine for a demo. */
function saveData() {
  localStorage.setItem("hh_volunteers", JSON.stringify(volunteers));
  localStorage.setItem("hh_joined", JSON.stringify(joinedEventIds));
}

function loadData() {
  var savedVolunteers = localStorage.getItem("hh_volunteers");
  var savedJoined = localStorage.getItem("hh_joined");
  // If something was saved, use it. Otherwise start with the sample data.
  volunteers = savedVolunteers ? JSON.parse(savedVolunteers) : sampleVolunteers.slice();
  joinedEventIds = savedJoined ? JSON.parse(savedJoined) : [];
}

/* ---------- 3. PAGE SWITCHING ---------- */
var navButtons = document.querySelectorAll(".nav-btn[data-view]");
var views = document.querySelectorAll(".view");

function showView(viewId) {
  // Hide every section, then show only the chosen one
  for (var i = 0; i < views.length; i++) {
    views[i].hidden = (views[i].id !== viewId);
  }
  // Highlight the matching sidebar button
  for (var j = 0; j < navButtons.length; j++) {
    var isCurrent = navButtons[j].dataset.view === viewId;
    navButtons[j].classList.toggle("active", isCurrent);
  }
}

for (var n = 0; n < navButtons.length; n++) {
  navButtons[n].addEventListener("click", function () {
    showView(this.dataset.view);
  });
}

/* ---------- 4. DASHBOARD ---------- */
function renderStats() {
  var activeCount = 0;
  var totalHours = 0;
  for (var i = 0; i < volunteers.length; i++) {
    if (volunteers[i].status === "Active") { activeCount++; }
    totalHours += volunteers[i].hours;
  }
  document.getElementById("stat-total").textContent = volunteers.length;
  document.getElementById("stat-active").textContent = activeCount;
  document.getElementById("stat-hours").textContent = totalHours;
  document.getElementById("stat-joined").textContent = joinedEventIds.length;
}

function renderUpcoming() {
  var list = document.getElementById("upcoming-list");
  list.innerHTML = "";
  // Show the first three events
  for (var i = 0; i < 3; i++) {
    var item = document.createElement("li");
    var title = document.createElement("strong");
    title.textContent = sampleEvents[i].title;
    var when = document.createElement("span");
    when.className = "muted";
    when.textContent = sampleEvents[i].date + " · " + sampleEvents[i].place;
    item.appendChild(title);
    item.appendChild(when);
    list.appendChild(item);
  }
}

/* ---------- 5. VOLUNTEERS ---------- */
var searchBox = document.getElementById("search");
var statusFilter = document.getElementById("status-filter");

// Makes one table cell with plain text
function makeCell(text) {
  var cell = document.createElement("td");
  cell.textContent = text;
  return cell;
}

// Draws the table using the current search word and status filter
function renderVolunteers() {
  var searchWord = searchBox.value.trim().toLowerCase();
  var chosenStatus = statusFilter.value;
  var tableBody = document.getElementById("volunteer-rows");
  tableBody.innerHTML = "";
  var shownCount = 0;

  for (var i = 0; i < volunteers.length; i++) {
    var v = volunteers[i];
    var text = (v.name + " " + v.skill + " " + v.city).toLowerCase();
    var matchesSearch = text.indexOf(searchWord) !== -1;
    var matchesStatus = (chosenStatus === "All") || (v.status === chosenStatus);

    if (matchesSearch && matchesStatus) {
      var row = document.createElement("tr");
      row.appendChild(makeCell(v.name));
      row.appendChild(makeCell(v.skill));
      row.appendChild(makeCell(v.city));
      row.appendChild(makeCell(v.hours));

      var statusCell = document.createElement("td");
      var badge = document.createElement("span");
      badge.className = "badge " + v.status.toLowerCase();
      badge.textContent = v.status;
      statusCell.appendChild(badge);
      row.appendChild(statusCell);

      tableBody.appendChild(row);
      shownCount++;
    }
  }

  // Friendly message when nothing matches
  document.getElementById("no-results").hidden = (shownCount !== 0);
  document.getElementById("result-count").textContent =
    "Showing " + shownCount + " of " + volunteers.length + " volunteers";
}

// "input" runs on every keystroke; "change" runs when the dropdown changes
searchBox.addEventListener("input", renderVolunteers);
statusFilter.addEventListener("change", renderVolunteers);

/* --- Add Volunteer form --- */
var volunteerForm = document.getElementById("volunteer-form");

document.getElementById("toggle-form-btn").addEventListener("click", function () {
  volunteerForm.hidden = !volunteerForm.hidden;
  if (!volunteerForm.hidden) { document.getElementById("v-name").focus(); }
});

document.getElementById("cancel-form-btn").addEventListener("click", closeForm);

function closeForm() {
  volunteerForm.reset();
  clearErrors();
  volunteerForm.hidden = true;
}

function clearErrors() {
  var fields = ["name", "email", "skill", "city", "hours"];
  for (var i = 0; i < fields.length; i++) {
    document.getElementById("err-" + fields[i]).textContent = "";
    document.getElementById("v-" + fields[i]).classList.remove("invalid");
  }
}

function showError(field, message) {
  document.getElementById("err-" + field).textContent = message;
  document.getElementById("v-" + field).classList.add("invalid");
}

// Returns true only if every field is OK
function validateForm() {
  clearErrors();
  var isValid = true;
  var name = document.getElementById("v-name").value.trim();
  var email = document.getElementById("v-email").value.trim();
  var skill = document.getElementById("v-skill").value.trim();
  var city = document.getElementById("v-city").value.trim();
  var hoursText = document.getElementById("v-hours").value.trim();

  if (name.length < 2) { showError("name", "Enter a name with at least 2 letters."); isValid = false; }
  // Very simple email check: something@something.something
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError("email", "Enter a valid email like name@example.com."); isValid = false; }
  if (skill === "") { showError("skill", "Enter a skill."); isValid = false; }
  if (city === "") { showError("city", "Enter a city."); isValid = false; }
  if (hoursText === "" || Number(hoursText) < 0 || isNaN(Number(hoursText))) { showError("hours", "Enter hours as 0 or more."); isValid = false; }
  return isValid;
}

volunteerForm.addEventListener("submit", function (event) {
  event.preventDefault();               // stop the browser from reloading the page
  if (!validateForm()) { return; }      // stop here if something is wrong

  var newVolunteer = {
    name: document.getElementById("v-name").value.trim(),
    email: document.getElementById("v-email").value.trim(),
    skill: document.getElementById("v-skill").value.trim(),
    city: document.getElementById("v-city").value.trim(),
    hours: Number(document.getElementById("v-hours").value),
    status: document.getElementById("v-status").value
  };
  volunteers.push(newVolunteer);        // add to the array
  saveData();
  closeForm();
  searchBox.value = "";                 // clear filters so the new row is visible
  statusFilter.value = "All";
  renderVolunteers();
  renderStats();                        // dashboard numbers update too
});

/* ---------- 6. EVENTS ---------- */
function isJoined(eventId) {
  return joinedEventIds.indexOf(eventId) !== -1;
}

function spotsLeft(eventItem) {
  var left = eventItem.capacity - eventItem.taken;
  if (isJoined(eventItem.id)) { left = left - 1; }   // your own spot counts
  return left;
}

function renderEvents() {
  var container = document.getElementById("event-cards");
  container.innerHTML = "";

  for (var i = 0; i < sampleEvents.length; i++) {
    var ev = sampleEvents[i];
    var card = document.createElement("article");
    card.className = "card event";

    var badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = ev.category;

    var title = document.createElement("h3");
    title.textContent = ev.title;

    var details = document.createElement("p");
    details.textContent = ev.date + " · " + ev.time + " · " + ev.place;

    var spots = document.createElement("p");
    spots.className = "spots";
    spots.textContent = spotsLeft(ev) + " of " + ev.capacity + " spots left";

    var button = document.createElement("button");
    button.type = "button";
    button.dataset.id = ev.id;          // remember which event this button belongs to
    if (isJoined(ev.id)) {
      button.className = "btn leave";
      button.textContent = "Leave event";
    } else if (spotsLeft(ev) <= 0) {
      button.className = "btn";
      button.textContent = "Event full";
      button.disabled = true;
    } else {
      button.className = "btn";
      button.textContent = "Join event";
    }
    button.addEventListener("click", handleJoinLeave);

    card.appendChild(badge);
    card.appendChild(title);
    card.appendChild(details);
    card.appendChild(spots);
    card.appendChild(button);
    container.appendChild(card);
  }
}

function handleJoinLeave() {
  var eventId = Number(this.dataset.id);
  if (isJoined(eventId)) {
    // Leave: remove the id from the array
    joinedEventIds.splice(joinedEventIds.indexOf(eventId), 1);
  } else {
    joinedEventIds.push(eventId);
  }
  saveData();
  renderEvents();
  renderStats();
}

/* ---------- 7. LOGOUT AND RESET ---------- */
var loggedOutScreen = document.getElementById("logged-out");

document.getElementById("logout-btn").addEventListener("click", function () {
  // confirm() shows a popup with OK and Cancel; it returns true if OK was pressed
  if (confirm("Are you sure you want to log out?")) {
    loggedOutScreen.hidden = false;
  }
});

document.getElementById("login-again-btn").addEventListener("click", function () {
  loggedOutScreen.hidden = true;
  showView("dashboard");
});

document.getElementById("reset-btn").addEventListener("click", function () {
  if (confirm("Reset all demo data? Volunteers you added and events you joined will be removed.")) {
    localStorage.removeItem("hh_volunteers");
    localStorage.removeItem("hh_joined");
    startApp();
  }
});

/* ---------- 8. START ---------- */
function startApp() {
  loadData();
  renderStats();
  renderUpcoming();
  renderVolunteers();
  renderEvents();
  showView("dashboard");
}

startApp();
